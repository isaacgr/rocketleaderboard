class HTTPCache(ValueError):
    pass


__all__ = ("HTTPCache",)
