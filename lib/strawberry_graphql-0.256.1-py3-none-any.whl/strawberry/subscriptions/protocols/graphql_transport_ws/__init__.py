# Code 4406 is "Subprotocol not acceptable"
WS_4406_PROTOCOL_NOT_ACCEPTABLE = 4406


__all__ = [
    "WS_4406_PROTOCOL_NOT_ACCEPTABLE",
]
